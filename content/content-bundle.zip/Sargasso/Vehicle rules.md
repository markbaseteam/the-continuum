**Use vehicle stats/pools for effort and edge.**
**Vehicles move down the damage track. 0 health pool = destroyed.**
**Players can assist and affect each other.**

Think of a vehicle as a character that is cooperatively played by the passengers.  **Vehicles have stat pools just like characters.**  They have effort limitations and edge.  The main difference is that players use the vehicle’s pools instead of their own.  It makes more sense to be able to take an engine’s might pool to see if you can squeeze a little power out of it than an engineering trained character using their own might to get out and push to add to the speed.  Just like players, once a vehicle has moved down the damage track to impaired, pools may no longer be used to add effort to tasks.  At debilitated, the vehicle is badly damaged and barely holding together.  It can neither move nor attack, and defense is limited. Once all pools are at zero, the vehicle is destroyed.

The idea is that the vehicle is operated collectively by the party so decisions should be made as a group.  Every turns provides only a limited amount of effort that can be applied to only limited areas of the vehicle.  Just like a regular character, pushing a vehicle's performance can result in cumulative damage since effort comes from the vehicles pools (with one exception).

Most vehicles have different ‘stations’ that can be manned by a single player.  A few examples might be: pilot, gunner, engineer, electronic warfare, communications, shielding, etc.  Each station will typically pay for effort out of specific pools, ie: piloting would use speed.  Players can use their trained or specialized skills to improve their chances at succeeding at any given task in addition to any effort from the vehicle.

The big difference in vehicle use is that the engineer enables other players to use effort by overdriving a vehicle subsystem.  Only one subsystem can be overdriven and provide effort to that particular station, which then can be used by whomever is crewing that station.  The engineer is the only party member to their own effort (Intellect based) to try and squeeze that much more.

Lt. Sulu is a pilot and has the piloting skill trained. He wants to pull a tricky turn past what is normally allowed so he can get his ship behind an asteroid.  His ship can usually move a short distance - vehicle distances are vastly faster than say walking, but appropriate to genre: slow for a spaceship might be hundred of kilometers/sec, whereas slow for a tank might be only a few Km/hour.  The thing is vehicles in battle would have parity of distance scaling.

Sulu wants to move enough to not only reach the asteroid, but also tuck in behind it.  This would be a long movement.  The GM looks at various things like what kind of shape Sulu's ship is in and decides that moving that far will require a piloting role to overcome a difficult task (level 4), and that Scotty the engineer first needs to roll to see if he can supply enough power for the maneuver.  The GM assigns Scotty’s task to overdrive the engine at 4 also.  Scotty has no training in Engineering, but he does have some aptitude with machines which the Gm allows him to use.  This brings the target to a level 3 task (9 on the dice), and Scotty decides to use 1 level of effort bringing it down to a level 2 task.  Scotty uses his intellect pool to see if he can get the engine to put out a bit more power.  Scotty's roll **allows** the crew to use effort from the engine.  

The effort, in this case, comes from the vehicle's speed pool, but Scotty's roll allows the crew to do this.  Without Scotty's engineering skill, no one would be present to try and squeeze a little more out of the engine.

Scotty rolls an 8 and succeeds at getting more power from the main drive to send to the maneuvering thrusters.  Sulu can now roll.  Since Scotty succeeded in overdriving the engine, Sulu now can use a level of effort on his piloting maneuver.  Sulu can't use his own pools to squeeze extra power or speed out of the ship since he can't get out and push.  That effort comes from the ship's engine, but Scotty has provided her crew the use of this effort.  

Sulu's piloting skill brings the task to a level 3 difficulty and with the extra level of effort from Scotty's overdrive, he feels confident in succeeding at a level 2 task.  Sulu rolls a 5 and fails.  The GM decides that Ralph didn’t make the turn, but the ship did go faster and move further than it usually does.


> **Vehicle stations & Combat**
> All stations get one action.  Everyone can briefly describe their planned action before the sequence actually starts.  A pilot could declare an intent to being evasive maneuvers while a gunner could declare her target and type of attack.
> *Engineering:* Can either repair or overdrive a single station/system.  Usually the first turn in a round so that any system overdrives can be utilized.
> *Pilot*: Steers the vessel, can choose to maneuver offensively or defensively. 
> *Gunner:* Attacks by declaring target and type of attack.
> *Electronics:* Can declare an offensive or defensive action.  Modern or futuristic vehicles can have many different kinds of offensive or defensive actions.  In a fantasy campaign, this station might be best utilized as magical offense or defense, or helping another station out and giving them an asset. 


>**Vehicle Damage Track:** **Optimal > Limited > Disabled > Destroyed**
>**Limited:** Functions normally but unable to use effort/ overdrive
>**Disabled:** Nonfunctional, but can be repaired in combat (most vehicles must be disabled to be boarded)
>**Destroyed:** Completely destroyed or only repairable in dry dock

---

#### **Engineering**
- **Repair a subsystem:** Roll against level of system to repair modified by table
Training / specialization: training is general, specialization is specific
Assist: Assistant engineers, repair systems, etc.
Effort: This comes from the Engineer themselves.  Intellect based.

- **Overdrive a subsystem:** to provide effort to other stations, modified by table
Training / specialization: training is general, specialization is specific
Assist: Assistant engineers, repair systems, etc.
Effort: **This comes from the Engineer themselves.  Intellect based.**

| Description                        | Modifier    |
| ---------------------------------- | ----------- |
| Restores (repairs) 6 points to pools  | 1           |
| Restores (repairs) 12 points to pools | 2           |
| Restores (repairs) 18 points to pools | 4           |
| Providing Overdrive                | +1 per level |



For example, the vehicle is a level 3 sailing ship.  The GM determines that attempting to overdrive the vehicle is a level 4 challenge. Vehicle level doesn't signify for overdrive other than limited the amount of effort that can be used per turn.  Bob the ship's engineer decides to attempt to gain 2 levels of effort for his crew.  This brings the challenge rating to a 6. Bob has some training in sailing vessels and a cypher which assists him with any task for 1 hour.  Together, these bring the challenge rating down to a 4.  Should Bob succeed, the crew would have 2 levels of effort to use that turn, to be divided as they choose.  This effort would come from the ship's pools, in this case speed.  Using the points from a pool depletes that pool just like any other player.  Regaining those points would require some minor repairs and use a short recovery period.

Second example: the vehicle has been damaged in a broadside cannon attack.  The damage was severe enough that the ship is listing and is disabled.  Bob attempts to repair the ship, rolling against the level of the vehicle (3) and trying to repair it from disabled to limited.  This adds 2 to the challenge rating and Bob now needs to beat a 15 (challenge level 5).  Again, Bob can use his sailing vessel training to reduce the challenge.  Audrey steps in and offers to help.  Bob also pulls out his silver shipwright's hammer for an asset.  These reduce the challenge rating to a 2.  Because Bob was busy building, there's no extra power this turn.

---

#### **Piloting**
- **Piloting**: roll against level of other vehicle modified by difference in levels & _table_
Assets: 
Training / specialization: training is general, specialization is specific
Effort: from engineering overdrive, if any

 - **Defense Rolls**: roll against level of other vehicle modified by difference in levels & Assets: evasive maneuvers, if any
Training / specialization: training is general, specialization is specific
Effort: from engineering overdrive, if any

  | Piloting            | Cost | Description                            |
  | ------------------- | ---- | -------------------------------------- |
  | Evasive maneuvers 1 | 2    | Eases defense by 1                     |
  | Evasive maneuvers 2 | 4    | Eases defense by 2                     |
  | Tail                | 3    | Follow without being seen              |
  | Line up the shot 1  | 2    | Gives Weapons 1 asset                  |
  | Line up the shot 2  | 4    | Gives Weapons 2 assets                 |
  | Flee                | 3    | 1 asset on losing pursuit              |
  | Boarding            | 2    | Only allowed against disabled vehicles |
  
>**Movement**
Movement is rated by a number. This is the number of squares or hexes a vessel can move. Using speed effort could boost this.

---

#### **Electronics**
- **Boost shields:** Roll against level of shields for boosting
Assets: Computer systems / AI, etc.
Training / Specialization: Trained in Starship ECM, Specialized in Starship Shield Manipulation Specialized in Starship ECM, etc.
Effort: From engineer - provides that many extra points of damage mitigation on successful roll

 - **EWAR attack:** roll against level of other vehicle modified by difference in levels & table
Assets: Computer systems / AI, etc.
Training / Specialization: Trained in Starship EWAR, Specialized in Starship Shield Manipulation, Specialized in Starship EWAR, etc.
Effort: From engineer - provides levels of easement for EWAR attacks.

| Shield manipulation | Modifier | Description                                                            |
| ------------------- | -------- | ---------------------------------------------------------------------- |
| Boost shields       | 2        | Provides (shield level) of damage mitigation points on successful roll |
| EWAR Attack         | 2        | Disables targeted subsystem                                            |
| EWAR Destruction    | 4        | Takes targeted subsystem down by one                                   |
|                     |          |                                                                        |

---

>**Weapons**
>**Attack:** Roll against level of other ship/system, modified by difference in levels & table
>Training / specialization: training is general, specialization is specific
>Assist: computerized targeting systems (to hit), Pilot’s offensive maneuvers (to hit)
>Effort: from engineering.  Only applies to damage

| Weapons            | Difficulty | Description                                                          |
| ------------------ | ---------- | -------------------------------------------------------------------- |
| Target Weapons     | 2          | Disables one weapon system for 1 round |
| Target Defenses   | 3          | Gives an advantage to all attacks next round       |
| Strike Vital Point | 5          | Either takes all systems down by one on the vehicle damage track     |
|                    |            | OR takes a single system down 2 on the vehicle damage track          | 
| Disable Engine     | 4          | Disables the target engine without damaging other areas      |

```




___
**Vessel level can be used to calculate the difficulty of a task: Task is eased by vessel level -1.  (A L1 vessel has no bonus, a level 4 vessel would have an easement of 3)

Weapns & Pools 
Level 1: 1 effort. 34 total (how to divide?)
Level 2: 2 effort, 38 total
Level 3: 3 effort, 42 total
Level 4: 4 effort, 46 total
Level 5: 5 effort, 50 total
Level 6: 6 effort, 54 total

Engineering 
Pilot (speed)
Electronics (intellect)
Weapons (might)

Once all the pool is exhausted, that station can't overdive anymore

Vessels need pools, effort, edge.
Scout/fast craft would have more speed edge



```ad-done
title: Vengence

Pirate ketch, Vengeance

Level: 2                              Armor: 1                          

Might: ___ / 13               Speed: ___ / 13               Intellect: ___ / 12

Might Edge: 1                  Speed Edge: 1                  Int Edge: 0

Weapons

2 Shard Cannon (4 damage, close)

1 Excimer laser (6 damage, long)

Boarding dock

```


```ad-faq
title: Shuttle

Level 1:                              Armor: 0

Might: ___ / 11               Speed: ___ / 13               Intellect: ___ / 10

Might Edge: 0                  Speed Edge: 1                  Int Edge: 0

No weapons

```

