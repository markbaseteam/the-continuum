**8/24/22**
Had thruster incident when moving out of dock: intrusion successfully avoided.  Virgil attempted to fix thruster, rolled a 1.  Mathias then collided with the asteroid destination damaging the ship

Took cargo to replace resupply cache as a guild mission
The cache appeared to have been broken into and lived in for a bit
	Ration bars had bites taken out and tossed aside - bites were not human
Guild took evidence for further processing 

Virgil got a job repairing ships/doing maintenance, low level income and big discount on ship use.

Virgil fixed his gun / came to an understanding with it.

---

### **9/7/22**
The 2 groups met sans Virgil in the wake of a bloodbath in an alley. Akasha and Falina were set on by a small group of Kif.  They all went to bar for a bit to talk, then went on a guild salvage mission.  Mistakes were made as T1m ripped open the airlock doors, blowing himself and Akasha into space.  Hilarious.  The group found some spices on the salvage ship along with some dead corpsicles.

Virgil was working on a repair in the dock and couldn't get away.

---
### **9/21/22**
Mathias hacks the computer and discovered a database of Indonesian outdoor scenes/movies that fetches a great price.  
The party hears about missing salvagers and start to explore rumors .  They contact the guildhall for information.  Parts for Mathias and Virgil's ship are not to be found.

The party uses proceeds of the last salvage to rent a bigger ship with guns to go to the last known salvage site of the missing friend.

T1m needed to go "lubricate his bearings" in private, and wasn't part of the session.

**The party assembled the following items for exploration:**
Hydrogen Plasma torch
Grapple gun
CO2 cylinders 
Emergency personal thrusters

---
### 10/19/22: Space battle 
The party responded to the story of a fellow salvager who was worried about a missing buddy.  He gave them the coordinates to the last known location of their ship. The party borrowed a ship and flew to the location provided where they were attacked by a pirate ship. After a brief skirmish in space, and after trouncing the boarding party from the pirate ship, the player party entered the pirate ship and confronted a man identified as Capt. Woobie.  

The good Captain was more than willing to negotiate with the party since Akasha had raised some of the dead pirates as zombies, breaking the mind of the one remaining crewmember and severely disturbing Woobie's mental equilibrium.

The party decided to repair the vessel and fly it to the pirate base as a trojan horse.  Akasha and Falina stayed with the original rented ship to repair it while the others went on to the pirate base.  The mentally broken crewmember, bereft of sanity, has decided to follow Akasha everywhere and insists that he be called Renfield. 
 


---
### 11/2/22: Avast! 

The party convinced [[Capt. Woobie]] that cooperating would be "beneficial to his health".  They repaired the captured pirate vessel, and after recuperating, flew to the pirate asteroid.  On the way, the party pressured [[Capt. Woobie]] to provide plans to the base and reassured him that they weren't going to kill him after he got them into the base.  Wooby talked them into the base and parked the ship.

The party (including Wooby) entered an airlock and made their way to a machine ship area (disappointing Virgil in its state of disorganization) and sneaked their way past a small group of pirates working on various projects.  They went down a hall to the door of [[Por Momiz]] and had Woobie knock.  On being asked, Woobie told Por he was back from his run but didn't get anything.  Por threatened bodily harm to Woobie and opened his door.

T1m quickly grabbed Por by the arm and trust him into the hallway.  Por was armed with a pistol so Mathias quickly shot Por in the arm in an attempt to disarm him.  Not only did Por drop the weapon, he was "disarmed" in the fullest sense as the plasma bolt caused massive tissue damage and detached his arm mid humoral shaft.  The party quickly grabbed Por and dragged him back into his room.

They roughly applied a zip-tie as a tourniquet and attempted to question Por.  Por refused to answer even after T1m removed a fingernail via main force.  Instead of continuing to torture the man, Mathias simply used his implants to hack the computer so thoroughly that after asking Por once for his password, Mathias simply reached back with one hand and typed the password 1st try while staring into Por's eyes.

The computer yielded info for the past six months on the names of ships the pirates had attacked, the loot they had collected, and the comings and goings of the pirates along with some nasty interspecies porn involving Grays.  The combination to the large safe was also on the computer. There were also references in correspondence to the [[Balacazar]] crime syndicate and a recent journal entry warning Por to extend every courtesy to N.V. otherwise Por could expect to have his head sent to I.V.

The safe contained 30k worth of jewelry, probably stolen from those the pirates had attacked and most likely killed. It also contained a sword of black metal that further investigation revealed to cause electrical shocks (when activated by twisting the handle) adding damage to its already sharp edge.

After taking everything including computer records and an unconscious [[Por Momiz]], the party decided to leave. On the way out of the maintenance area, things almost got dicey but the party was able to bluff the pirates using the name [[Menon Balacazar]]  as to why their current boss was unconscious and being carried out of the base. In passing a previously unremarked shipping container, pounding was heard from inside and the party realized there were probably prisoners in the container. They decide they should try and free the prisoners even if it might spark a fight, but again the party was able to again convince the pirates that 1) they were there representing a higher level of authority than their recent boss, 2) they were not to be messed with, and 3) the pirates needed to scatter because the base was about to be attacked.

The party then had the pirates help them load the prisoners onto the commandeered pirate ship and flew off with an injured [[Por Momiz]] and Woobie.  They then flew without incident back to Bedrock where they gave the [[Salvager's Guild]] all the information about the location of the pirate base and the missing ships.  The guild master was both grateful to the party and supremely angry with City Hall for denying the missing ships were anything unusual. 

---
### 11/16/22: The Shining Endeavor Part 1

The party gets a hot tip that a new energy source has been discovered in the Sargasso and they are given the rights to delve.  They set off and after nearly a week of travel find a massive colony ship.  It is kilometers long with cargo and docking bays near the engines, and a radioactive hole torn in the side part way up the hull toward the bow.  They find the words "Shining Endeavor" printed on the side of the ship in letters hundred of feet high.

One docking bay is filled with the shattered debris of dozens of ships.  Rather than pick their way through or search for anything, the party decided to go to the other docking bay.  The second bay's doors were shut but buckled with enough of a gap that a suited human sized creature would slip inside.

On entering, the party discovered a single alien vessel that was difficult to perceive with eyes or sensors.  The party left without trying to find an entrance to the smaller ship in the bay, and instead found an entrance into the colony ship proper.

The party made their way through abandoned and empty rooms and hallways, some nearly clogged with detritus and broken machinery.  At one point the party discovered a smoke like creature with many limbs sorting through the liter covering the floor.  The party decided to approach the creature without attacking it, and the creature offered to trade cyphers.

The party continued on and discovered the Reefersleep cryonic storage areas where the colonists had been frozen for the journey.  Half of the reefersleep caskets were empty, while the other half contained the desiccated remains of the travers who had died en route.


---
### 11/30/22: The Shining Endeavor Part 2

Akasha asked some of the cryocorpses what happened to them, where they were going , etc.  The colony ship was headed from Earth to Alpha Century and all the corpses were from colonists as opposed to crew members. The party continued on out of cryogenics into a long hallway and were waylayed by 2 nanite constructs.  After defeating the constructs and finding 4 cyphers, the party continued on and discovered the mess hall: a multilevel balconied area with seating for hundreds.  While checking out food supplies (none), the gravity went out, but everyone was able to grab ahold of something.  T1m floated up one level but grabbed the balcony railing and pivoted over it as gravity returned.  The party then continued on, but with increasing power and gravity fluctuations plaguing them.

They continued to the bridge only to find out there was vacuum on the inside preventing the door from opening.  The party braced themselves while Mathias carefully burned a small hole through the door.  The atmosphere bled out of the hallway eventually triggering the closure of an emergency bulkhead and sealing the area.  The bridge door opened to reveal a burned out and shattered husk of a room open to space.  Akasha used her powers to determine that the incident happened from within the bridge rather happening externally.

The party resealed the hole in the door, hiked to the bulhead, and made another hole in that.  Pressure then equalized between the areas allowing the bulkhead door to open.  The party then decided to follow the signs to Hydroponics.

After removing debris blocking the entrance to hydroponics, the party entered to find a near jungle of overgrown plants and even trees filling the chamber.  The area itself was a km long and hundred of feet high with the terraced balconies of crew apartments overlooking the area.

After 30 minutes of travel, the party came across a wireframe tree in a small clearing which promptly attacked T1m with razor sharp limbs.  As it fought, the wireframe changed to resemble a robot.  The wireframe construct damaged T1m quite heavily before Falina jumped in and blocked with her shield, drawing the construct's attacks and allowing T1m to recover somewhat.  The construct was eventually defeated, ending the session.


