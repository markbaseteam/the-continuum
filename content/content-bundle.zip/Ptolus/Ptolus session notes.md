Session 1: The adventure begins
---
The party meets in Ptolus for the first time and agrees to delve under the city together.  They get information on the Delver's Guild, decide to join, and accept their first commission: to resupply one of the guild's caches.
In following their map, they came across a chasm.
Bruno, the half-halfling mage, leaps across with rope, ties it off on the other side.  Several of the party make it across before giant spiders, alerted by the torchlight and noise come to investigate.
The party fights them off, but Cherry nearly losses one of her hatchets when her grip slips.

After fighting the spiders, the party continues on.  As they are making their way down a long natural corridor, Trisstina notices part of the floor looks like it's been covered up. Bruno tosses a small rock, causing the false floor to sag.  Ailwin throws a rope onto it, collapsing the false floor and revealing a spiked pit trap.

Ailwin tries to jump the trap, fails and slams into the side with his arms and chest slamming into the wall. Bruno tries to jump, and also slams into the far side. Trisstina easily leapt across, followed by Cheery who also slammed into the far side of the pit. Raya is able to leap across without issue.

The party then stays the night in a fountain room, but were jumped by goblins in the last watch. Trisstina threw a fire bomb into the hallway entrance where the goblins were firing missiles from and kills most of them.

---
Session 2: The many legged ones
---
The party successfully raiding the Temple of the Centipede rescuing the Litorian, Kiliec in the process.  They also found a symbol of a stylized jagged dagger on a pendant on lead cultist.  The party introduces themselves to Kiliec who tells them he owes them a life debt.

---
## Session 3: Ailwin's brother's ring
The party heads to a pawn shop and Bruno finds a ring he likes to buy for his mother.  Ailwin recognizes it as belonging to his lost brother - a family heirloom that the scion of the house always wears.  Bruno surrenders the ring and helps to interrogate the pawn shop owner.  She claims that the ring was sold to them by a character known as [[Fenwick Fast Fingers]]

The party tracks Fenwick to the [[Sunflower Café]] where they engage him in a card game to drawn him out.  Fenwick claims that the ring was won in a card game from a dwarven coppersmith who works at a copper smithy called the [[COPPER KETTLE]].  

The dwarven smith took the ring in payment for working on a commission.  He was given some old copper, told to use only that metal, and save anything not used to be taken when the commission is picked up.  The customer dressed in a dark and hooded cloak, and never revealed his face or name.  The copper was worked into several vessels that would be used for alchemy and picked up by the customer.  The dwarf smith says a few days afterword, he actually found a bit of the copper that had fallen behind some other projects and was saving it for the customer.  He gave it to the party instead, at their request.  He also mentioned that the copper objects look similar to objects previously brought up from delvers working in a specific area.

---
## Session 4: Oct 22, 2022: There's a Badger down there!
Kiliec is approached by a human who offers a commission from [[House Kath]] to find a statue for that was stolen 200 years previously.  It's a white marble statue of a beautiful angel playing a lyre.  The commission is a bounty only for the statue's return

###### Trisstina's House 
Trisstina is upset because her house was burgled a week ago. Kiliec then goes to Trisstina's house where he finds Ailwin and Trisstina and says he has news of a commission to retrieve a statue from the delvings, but doesn't want to explain more than once. The three go to Bruno's house but find he's out of town.

###### Cherry's House
They go to Cherry's house. The door is locked but they hear roaring from inside.  [[Jerry (Kiliec)]] breaks the door down and they enter and search.  They find an empty house except for a newly built reinforced cell in the cellar.  Something large inside is roaring and battering on the door. 
 Kiliec smells badger.

The party decides to leave well enough alone.  They fix her front door.  They party discusses [[The Green Toad]] fact that the neighbor thinks Cherry is "goofy", and then wonder about lycanthrope.  They realize that the moon is full.  They go to a nearby bar called [[The Dead Drunk]].  The bartender is confused when they ask for a Cheery Littlebottom and think they're looking for a whore.  The next day Cheery goes to Trisstina's house and explains that that her family has been cursed with lycanthrope and her necklace has been stolen.  It washer in the cell and she would have attacked the party if they had let her out.

###### Finding the thief
They enlist a mage, Jevicca Nor, to help them find who took the necklace.  For 10s, Jevicca is able to imprint the face into a small crystal ball.  They take it to Kiliec's contact in the city watch, but he hasn't seen the face before.  The party then goes to the Sunflower Café and talks to  [[Fenwick Fast Fingers]] who identifies the thief as [[Vagger Nulus]], and up and coming thief who specializes in commission thefts.  Vagger is not loved by other thieves since he sold something partners out to the city watch.  Fenwick tells the party that Vagger can be found at the [[The Sorn]], a dive bar near the docks.

The party spots Vagger walking toward [[The Green Toad]] and attempts to waylay him.  Kiliec grabs him near an alley, but ends up with a lot of cloak as Vagger runs down the alley.   [[Ailwin Feirwai]] puts an arrow in Vagger's knee which ends Vagger's adventuring. As the partystarts  starts to question Vagger, the city watch interrupt and things might have gone badger  but Kiliec tells them of his contact with the City Gaurd leadership.  Vagger is quickly questioned  and reveals that he was hired by [[Urnest Ankismar]] , a priest of the Rat God.  He's then led away by the city gaurd.

###### [[NPCs, Organizations, Locations/Organizations/Temple of the Rat God]] 
The party makes it's way to the Temple District and find that the rat God is reviled by most people.  They find his sanctuary but it's currently empty of everything except rotting garbage and trash.  A statue of the rat god stand at one end of the room.  Scrape marks on the floor at the base of the statue lead the party to push and pull until it moves revealing stairs going down.  The party goes down the steps to find an even filthier room.  They take the only hallway leading from it and are ambushed by 4 rat-men.  As they're fighting, the rat-men are joined by 5 giant rats.  The party mange to kill all of them, but Kiliec has been bitten by a rat and the wound is already feverish.


___
## Session 5: Oct 29, 2022    The Necklace

As Kiliec, Cheery, Ailwin, and Trisstina were fighting the rat-men and giant rats, Raya and Bruno were making there way through the sanctuary of the rat god.  They discovered the moved statue with the stairs, and had heard fighting from below.  They showed up just as the fight ended, after finding the note, and following the directions that Ailwin had left at Bruno's house.

Kiliec, feeling feverish from his rat bite, decides to seek a healer and leaves the party by going back up the stairs.

###### The Bedroom
The rest of the party continue on through the cellars until they find a bedroom that had seen better days. In fact, it's seen better decades. What was once a large bed is centered along one wall. The frame collapsed some time ago, and old and dirty blankets have been added to the pile of bedding to make a kind of disgustingly filthy nest surrounded by broken boards and splintered bedposts. Fecal material, like giant rat turds, litter the floor.

The ceiling and walls are of smooth, dressed stone, mortared with something dark that is crumbling and leaving large gaps between some of the stones where you can see insects or even rats have made their way into the chamber. A couple of ratty tapestries, with what looks and smells like feces, are hanging on the walls. A kludged together desk made of broken boards, a small crate, and a rotting barrel sits to one side of the room with a small lantern and a book on it. A surprisingly sturdy, small chest sits next to the desk.

###### The Journal of [[Silion Ankismar]] 
Most of the journal is wither boringly mundane, stained beyond legibility, or dealing with the everyday petty thoughts of an extremely vindicate woman.

She met Urnest 10years ago and while initially repulsed by him, became drawn to his power. She eventually studied with him, married him, and surpassed him in the arcane arts while he became more and more drawn to the giant rats.  For a few years now he's all but ignored other humans, including Silion, which has been fine with her as she pursues her own dark quest for power.

Three years ago she found a half rotted manuscript with a summoning ritual for the [[Galchutt]].  She used this to make contact with [[Abhoth]].  At this point in her journal she starts to get very excited.  [[Abhoth]] is teaching her new things almost daily and promising her power in exchange for it's freedom.  Within a week of communicating with [[Abhoth]] for the 1st time, her journal entries starts to degenerate noticeably in the sanity department.  She goes of on rants for sometimes 10 pages or more about a single item, like an apple she bought from a vendor, or sometimes the same word will be repeated across several pages.

The last few weeks of entries are all but incomprehensible.  The last semi-coherent entry you can dredge out of the insanity is that she is trying to collect items of power to free [[Abhoth]].  She thinks that if she has enough magical items she can open a portal and free her new lord.

##### The Summoning
After "picking" the locked chest with a dagger, the party finds some gold and promptly steals it.
More searching of the room by Bruno yields a concealed and locked door behind one of the filthy tapestries, and small stone levers in each corner of the room.  Some fiddling with the levers opens the locked door.

The party makes their way down a short hallway to a door behind which they hear chanting. On opening the door they find themselves at the back of large worship hall half filled with human acolytes and a scantily dressed but extraordinarily dirty woman behind an alter at the top of the room.  She is facing the party and points and screams altering her minions to the party.

The party engages in a grand melee as 15 cultists attack the party as the priestess continues to chant.  As she continues with her spell, a portal opens above the alter.  It's a sphere of putrid purplish green about 3 feet across.  Raya and Ailwin both manage to put arrows into the priestess who then collapses (or at least ducks) behind the alter, chanting weakly.

A giant grasshopper leg, covered in filth and an assortment of random tentacles, spines, and bristly hair emerges from the portal.  The leg extends nearly 30 feet into the room, but it's taking up most of the portal space which is now fluctuating alarmingly.

The party has defeated the cultists at the point and run toward the alter when Silion screams, "Take it, my lord!" and throws something small into the portal.  The party arrives at the alter to find that Silion has escaped through a hatch just behind the alter.  The party weigh the consequences of actions and decide to attack the eldritch horror.  As they are attacking the leg, the portal finally collapses, severing the leg and leaving it on this side.

##### The Chase
The party decide to quickly follow Silion despite being injured and needing to recuperate.  They realize that if they don't follow her now, they may never catch her.  After following a trail of blood to a secret door in the Blessed Bridge in the Temple District, the party find themselves next to a market.  Trisstina spots their quarry  attempting to hide by blending into the crowd.

As the party moves toward her, Silion starts to run again, but Bruno leaps nearly 80 feet and lands in front of her.  Silion quickly changes direction and shoves a mother holding an infant, which then flies into the air.  Bruno manages to catch the child and in the process finds that the diaper has come off.  He quickly throws it under Silion, who has been slowed by the crowd, causing her to slip and fall backwards.  The party is able to easily capture the woman at this point as several women look down favorably on Bruno for rescuing the baby and using a diaper with such panache.

The City Guard shows up demanding an explanation which the party begins to provide.  The officer quickly stops them, mumbling about pay grades, and sends for his sergeant.  This man then sends for his captain.  The captain demands to see the temple and gets a little wild eyed on seeing the monstrous leg.  He then in turn sends for Jevicca Nor.  After reading the journal and interrogating Silion, Jevicca becomes very serious and explains to the party about the Galchutt and Abhoth.  Silion had been trying to open a portal to free Abhoth by using magical items as power sources.  The party finds out that Cheery's necklace was the small object thrown into the portal earlier.  On hearing this Cheery starts to choke Silion, but backs off when Jevicca explains that the necklace was actually cursed and preventing Cheery from reaching her potential in her were form.

---
Session 6: Nov 12 - The [[Briar Rose]] 
---
[[Jevicca Nor]] has asked the party to investigate the disappearance of an informant nicknamed Mouse.  Mouse reported strange activity at night near the neighborhood of an inn called the Briar Rose in Eastern Midtown.  Jevicca also introduced a Litorain Knight named Ranni, who is to go with assist the party in a semi-official capacity and keep them out of trouble.

The party go to the inn, but decide to scout a bit before going inside. This large three story Inn sits in Midtown right against the seacliffs to the East and the Necropolis wall to the North. The building doesn't look like it's been painted in living memory. Weeds and thin grass grow between the flagstones of the small courtyard on the South side, while the whole edifice leans somewhat alarmingly toward the North.

Trisstina and Ailwin see a couple go into the bar.  Cheery, Kiliec, and Ranni investigate the inn's yard. There is a locked cellar door on the south side of the inn, and a paved courtyard in back with a two-seater outhouse at the edge of the cliff.  The whole area smell terrible, but Kiliec smells rotting meat under the normal outhouse smells. Kiliec and Ranni use their sensitive Litorian noses to figure out that the rotting meat smell is actually coming from somewhere down the cliffs and not the outhouse.  They attempt looking over the cliff but are unable to see anything.

Trisstina and [[Ailwin Feirwai]] decide to enter the bar.  All the tables are full and the inn, although dark inside, seems like it's doing a good business.  Ailwin first attempts to go upstairs but is blocked by a very unfriendly woman.  He goes back downstairs and attempts to read the title of a book being read by a clean cut dwarf, but is noticed by the now angry dwarf.  Ailwin and Trisstina decide to leave.  Of note, there was a woman sitting a wooden throne on a small stage to one side of the common room.  She sat behind a long table on the stage and was flanked by a one eyed dwarf and a half-elf who was sporting a lot of scars.

Kiliec, Cheery, and Ranni move back to the front of the front of the inn and join Ailwin and Trisstina.  Bruno and Raya also join the party at this point.  After some discussion, the party gathers some rope and belays Bruno of the edge of the cliff. He descends 30 feet and find a crevice wide enough to admit a average sized humanoid.  The party tie off the rope and one by one climb down to the crevice.  Cheery loose her grip and is only saved from plummeting to her death by getting her leg caught in the rope and hanging upside down until she can be rescued. Raya also falls, but ends up getting her arm caught in the rope on the way down and damaging her shoulder.

The party eventually all enter the crevice where, after a short trip down a passage, hear the gnawing and snap of bones being chewed.  The smell here is so bad that Bruno vomits, making air slightly cleaner.  The party discover a cave with 4 ghouls in it. The party wins the ensuing battle, but the noise draws even more ghouls, and another 6 come down the passage and into the cave. The party also win this fight, although some are serious hurt.  An old sliver amulet is discovered on the body of he ghoul's latest meal. They decide to continue and come to another cave littered with bones.  

As the party is investigating the cave (finding a few cyphers), some garbage rains down on them from the high ceiling overhead.  Bruno floats up to a shadowed area and finds a natural chimney.  He follows this up and finds an unlocked iron grate.  He is able to stealthily move this and poke his head up into what turns out to be the common room of the inn.  The grate is set to one side, next to the stage where the one eyed dwarf is sitting.  Bruno carefully replaces the grate and tells the group what he found.

The party explore a little further finding a dead end tunnel, and another tunnel to the north that lead 150 feet to a small cave in.  Cheery's underground directional senses tell her that the party is under the [[Necropolis]].  Rather than clearing the cave in, the party decides to inform Jevicca of what they have found.

Jevicca is concerned by the tunnel and use of ghouls to dispose of bodies and lends the party 20 guardsmen to help them.  Kiliec becomes assertive when discussing plans and tells the party that they should make the gang in the inn come to them.  The party then acquires several magical smoke bombs and in a dawn raid surprised the inn's gang who were captured without a fight.  After capturing 17 bandits, the party searched the inn and found some treasure in the wooden throne and two locked rooms on the 3rd floor.  One room, barred from the outside, contains a days old body with teeth marks on it's neck.

The other room contains the body of the woman who was seated on the throne earlier.  Figuring a dead body has nothing to loose, Bruno drives a stake through her, waking her and causing a bit of a mess.  Vampire down.                                                                                                                                                                                                                                                                                                                                                                                                                                                          

[[Jevicca Nor]] is pleased with the group and rewards each $500.  The party had also found 10 gems in a secret compartment in the throne, but haven't valued them as yet.  
Everyone earns 2 xp with the party voting 1 extra to Kiliec.

---
## Session 6: Nov 19 - The City of Doren Brohir

The party receives an invitation to contact the Guild Master of the Delver's Guild in Ptolus.  Unfortunately the messenger was unable to locate several of party members. Ailwin, Bruno, and Raya were told time was of the essence. They decided to act sooner rather than later and met immediately with the Guild Master.

Because of their outstanding handling of the Briar Rose incident, he wants to offer them first right of refusal on a new delve that's just opened up - into what looks like the upper reaches of a Dwarven mine.  The three pack up to go, but realize that because of the sheer quantity of supplies that they want to bring, their packs will be so heavy that fighting in them would put them at a disadvantage.  The party discussed the issue and decided to take what they could with the idea that they would take off the packs when anticipating a fight, or at the soonest possible moment.

The party also met briefly with Jevicca Nor, who gave them a [REDACTED] spell.

The party descended without incident for several days, locating the new area and following a large tunnel until it ended in a large chamber bisected by a stone wall that ran all the way from side to side and all the way to the ceiling.  Two massive doors of iron and oak open into the wall. There were arrow slits in the wall, and Bruno discovered murder holes in the lintel of the entranceway by floating up like a small balloon.  The left-hand door was slightly ajar - enough that the party could enter one at a time.

They found an entrance courtyard flanked by guardrooms and balconies that would allow for plunging fire into the yard - but all was deserted.  The far end of the courtyard had another set of massive double doors that were also slightly ajar.  These showed a red light, like firelight, reflecting from beyond the threshold.

The three went through and found themselves in a immense cavern, literally over a mile across and hundred of feet high, lit from below by a flowing river of magma.  The cavern contained an entire dwarven city.  The entrance opened onto an elevated island of sorts in a bend of the river with the major portion of the city on the other side of the magma.  A stone bridge slanted down from the upper city where they currently were to the city below.

The party found themselves standing in the ruins of a large outdoor (outside of buildings, but yes, underground and in a cave) market.  The detritus of rotted wood and cloth from stalls was intermixed with other debris.  The party searched, but didn't find any bodies or remains.  Many buildings occupied the area around the market square, and the three decided to explore a bit.  

After investigating several deserted houses, and then avoiding a confrontation with a group of animals, the party was able to find some warehouses.  Most of these were abandoned and either clear of most goods, or filled with rotting and worthless items.

After fighting a small group of spiders, the party located a small warehouse that was tightly locked up. Ailwin burned a cypher that unlocked the door and the party found themselves in a jeweler's or fine metalsmith's shop.  Ailwin found a beautiful bow, made of a light gray wood and inlaid with sliver among some weapons racked on a wall. Bruno found some material for enchanting.  The three decided to close and bar the door so they could rest.